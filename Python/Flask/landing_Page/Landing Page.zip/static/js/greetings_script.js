alert("Hellooo this is my JS working for this assignment! :D")
